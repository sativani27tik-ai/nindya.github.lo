const defaultMenus = [
 {id:1,name:"Dimsum Original",category:"Original",price:18000,description:"Dimsum kukus lembut dengan rasa gurih klasik.",image:"images/original.jpg",emoji:"🥟"},
 {id:2,name:"Dimsum Mentai",category:"Mentai",price:24000,description:"Dimsum dengan saus mentai creamy dan gurih.",image:"images/mentai.jpg",emoji:"🧀"},
 {id:3,name:"Dimsum Bakar",category:"Bakar",price:22000,description:"Dimsum bakar dengan aroma panggang yang menggoda.",image:"images/bakar.jpg",emoji:"🔥"},
 {id:4,name:"Dimsum Mercon",category:"Mercon",price:20000,description:"Pilihan pedas untuk kamu yang suka sensasi mercon.",image:"images/mercon.jpg",emoji:"🌶️"},
 {id:5,name:"Dimsum Udang",category:"Udang",price:25000,description:"Dimsum dengan udang yang lezat.",image:"images/udang.jpg",emoji:"🍤"}
];
const STORAGE_MENU="dapoerGametMenus_v2", STORAGE_CART="dapoerGametCart_v2";
let menus=loadMenus(), cart=loadCart(), activeFilter="Semua";
function loadMenus(){try{const s=localStorage.getItem(STORAGE_MENU);return s?JSON.parse(s):[...defaultMenus]}catch{return [...defaultMenus]}}
function loadCart(){try{return JSON.parse(localStorage.getItem(STORAGE_CART))||{}}catch{return {}}}
function saveMenus(){localStorage.setItem(STORAGE_MENU,JSON.stringify(menus))}
function saveCart(){localStorage.setItem(STORAGE_CART,JSON.stringify(cart))}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n)}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function getMenu(id){return menus.find(m=>m.id===Number(id))}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2500)}
function renderMenus(){
 const grid=document.getElementById("menu-grid"), visible=menus.filter(m=>activeFilter==="Semua"||m.category===activeFilter);
 if(!visible.length){grid.innerHTML='<p class="empty-cart">Belum ada menu di kategori ini.</p>';return}
 grid.innerHTML=visible.map((m,i)=>`<article class="menu-card" style="animation-delay:${Math.min(i*70,350)}ms"><div class="food-photo">${m.image?`<img src="${esc(m.image)}" alt="${esc(m.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='block'">`:""}<span class="food-emoji" style="${m.image?'display:none':''}">${esc(m.emoji||"🥟")}</span><span class="category-tag">${esc(m.category)}</span></div><div class="menu-info"><h3>${esc(m.name)}</h3><p>${esc(m.description||"Camilan lezat dari Dapoer Gamet.")}</p><div class="menu-bottom"><span class="price">${rupiah(m.price)}</span><button class="add-cart" type="button" data-add="${m.id}" aria-label="Tambah ${esc(m.name)}">+</button></div></div></article>`).join("");
}
function renderCart(){
 const box=document.getElementById("cart-items"), selected=Object.entries(cart).map(([id,qty])=>({menu:getMenu(id),qty})).filter(x=>x.menu&&x.qty>0);
 document.getElementById("cart-count").textContent=selected.reduce((s,x)=>s+x.qty,0);
 document.getElementById("cart-total").textContent=rupiah(selected.reduce((s,x)=>s+x.menu.price*x.qty,0));
 box.innerHTML=selected.length?selected.map(({menu,qty})=>`<div class="cart-line"><span class="cart-line-name">${esc(menu.name)}<br><strong>${rupiah(menu.price*qty)}</strong></span><div class="qty-control"><button type="button" data-minus="${menu.id}">−</button><span>${qty}</span><button type="button" data-plus="${menu.id}">+</button></div></div>`).join(""):'<p class="empty-cart">Belum ada menu. Yuk pilih camilan di atas!</p>';
}
function changeQty(id,n){const k=String(id);cart[k]=(cart[k]||0)+n;if(cart[k]<=0)delete cart[k];saveCart();renderCart()}
const cheer={Semua:"Pilih menu yang bikin kamu ngiler!",Original:"Klasik, lembut, dan gurih! 🥟",Mentai:"Creamy, gurih, bikin nagih! 🧀",Bakar:"Aroma bakarnya bikin lapar! 🔥",Mercon:"Berani coba sensasi pedas? 🌶️",Udang:"Favorit pencinta seafood! 🍤"};
document.getElementById("filters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;activeFilter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));const grid=document.getElementById("menu-grid");grid.classList.remove("refresh");void grid.offsetWidth;grid.classList.add("refresh");document.getElementById("cheer-text").textContent=cheer[activeFilter]||"Menu lezat menanti kamu!";renderMenus()});
document.getElementById("menu-grid").addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;changeQty(b.dataset.add,1);toast("Menu masuk ke keranjang! 💛")});
document.getElementById("cart-items").addEventListener("click",e=>{const p=e.target.closest("[data-plus]"),m=e.target.closest("[data-minus]");if(p)changeQty(p.dataset.plus,1);if(m)changeQty(m.dataset.minus,-1)});
document.getElementById("add-menu-form").addEventListener("submit",e=>{
 e.preventDefault();const name=document.getElementById("new-name").value.trim(),price=Number(document.getElementById("new-price").value),category=document.getElementById("new-category").value,description=document.getElementById("new-description").value.trim(),file=document.getElementById("new-image").files[0];
 if(!name||!Number.isFinite(price)||price<=0){toast("Cek nama dan harga menu, ya.");return}
 const add=image=>{menus.unshift({id:Date.now(),name,price,category,description,image:image||"",emoji:"🥟"});try{saveMenus();activeFilter="Semua";document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter==="Semua"));renderMenus();e.target.reset();toast("Menu baru berhasil ditambahkan! ✨")}catch{menus.shift();toast("Penyimpanan penuh. Coba foto yang lebih kecil.")}};
 if(file){if(!file.type.startsWith("image/")){toast("Pilih file gambar, ya.");return}if(file.size>1.5*1024*1024){toast("Foto maksimal 1,5 MB.");return}const r=new FileReader();r.onload=()=>add(r.result);r.onerror=()=>toast("Foto gagal dibaca.");r.readAsDataURL(file)}else add("");
});
const delivery=document.getElementById("delivery-method"),addressLabel=document.getElementById("address-label"),address=document.getElementById("customer-address");
function updateAddress(){const yes=delivery.value==="Antar";addressLabel.classList.toggle("hidden",!yes);address.required=yes}
delivery.addEventListener("change",updateAddress);
document.getElementById("order-form").addEventListener("submit",e=>{
 e.preventDefault();const selected=Object.entries(cart).map(([id,qty])=>({menu:getMenu(id),qty})).filter(x=>x.menu&&x.qty>0);
 if(!selected.length){toast("Keranjang masih kosong. Pilih menu dulu, ya!");document.getElementById("menu").scrollIntoView({behavior:"smooth"});return}
 const name=document.getElementById("customer-name").value.trim(),phone=document.getElementById("customer-phone").value.trim(),method=delivery.value,addr=address.value.trim(),total=selected.reduce((s,x)=>s+x.menu.price*x.qty,0);
 const lines=selected.map(x=>`• ${x.menu.name} x${x.qty} — ${rupiah(x.menu.price*x.qty)}`).join("\n");
 alert(`RINGKASAN PESANAN — DAPOER GAMET\n\nNama: ${name}\nNo. HP: ${phone}\nMetode: ${method}${method==="Antar"?`\nAlamat: ${addr}`:""}\n\n${lines}\n\nTOTAL: ${rupiah(total)}\n\nIni hanya demo tugas sekolah, bukan pesanan sungguhan.`);
});
renderMenus();renderCart();updateAddress();
