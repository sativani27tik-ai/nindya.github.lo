DAPOER GAMET — FOTO & ANIMASI
================================

Isi folder:
- index.html
- style.css
- script.js
- images/ (lima foto makanan)

CARA MEMBUKA:
1. Pastikan ketiga file dan folder images tetap berada dalam satu folder.
2. Klik dua kali index.html untuk membuka website di browser.
3. Jangan pindahkan file foto keluar dari folder images.

CARA UPLOAD KE GITHUB PAGES:
Upload index.html, style.css, script.js, dan folder images beserta semua isinya ke root repository.
Aktifkan Settings > Pages > Deploy from a branch > main > /(root).

FITUR:
- Lima kategori menu: Original, Mentai, Bakar, Mercon, Udang.
- Foto lokal, animasi ayam dan kartu menu.
- Keranjang dan ringkasan pesanan demo.
- Form untuk menambah menu dan foto, tersimpan hanya di browser lokal.

CATATAN:
- Formulir belum mengirim pesanan sungguhan atau menerima pembayaran.
- Menu yang ditambahkan lewat form tersimpan pada browser yang digunakan, tidak otomatis terlihat oleh pengunjung lain.
- Foto yang disediakan berasal dari pengguna dan disebut diambil dari Pinterest. Pastikan memiliki izin atau hak penggunaan sebelum website dipublikasikan secara umum.
